// Standard library includes
#include "MeAuriga.h"
#include <Wire.h>
#include <Me7SegmentDisplay.h>

#include <Farmhand.h>
#include <moistureSensor.h>
#include <pump.h>
